#!/usr/bin/env python
"""
DAFoam run script for the curved cube case
"""

# =================================================================================================
# Imports
# =================================================================================================
from mpi4py import MPI
from dafoam import *
import sys

allOptions = {
    "solverName": [str, "DASimpleFoam"],
    "printAllOptions": [bool, False]
}

from pyTestDAFoamIncompressible import pyTestDAFoamIncompressible

solverArg = "tests -python"
tests = pyTestDAFoamIncompressible(solverArg.encode(), allOptions)
tests.test1(allOptions)

