#!/usr/bin/env python
"""
DAFoam run script for the curved cube case
"""

# =================================================================================================
# Imports
# =================================================================================================
from mpi4py import MPI
from dafoam import *
import sys
import petsc4py
petsc4py.init(sys.argv)
from petsc4py import PETSc

aeroOptions = {
    "solverName": "DASimpleFoam",
    "printAllOptions": False,
}
CFDSolver = PYDAFOAM(options=aeroOptions)

meshOK = CFDSolver.runCheckMesh()

CFDSolver.initSolver()

CFDSolver.runPrimalSolver()

CFDSolver.setOption("flowEndTime", 100.0)
CFDSolver.runPrimalSolver()
